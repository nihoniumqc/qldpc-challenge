"""Bounded halved-CPM pilot, using unchanged official searches and packaging."""

import argparse
import copy
import json
import platform
import sys
import time
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
for directory in [ROOT / "research", ROOT / "research/kit", ROOT / "verify", ROOT / "cli"]:
    sys.path.insert(0, str(directory))

import build_halved_pp as halved
import heuristic_distance as hd
import qldpc as cli
import qldpc_verify as qv
from campaign import Ledger, load_campaign, scaffold_campaign, write_campaign, write_summary
from coordination import unique_path
from submit import save_submission

PIN = "20300a96a1d8ee4d766cf250352aaae14963a610"
SEED = 2026102300


def dump(path, obj):
    path.write_text(json.dumps(obj, indent=1) + "\n")


def stage(doc, label):
    (HERE / "documents").mkdir(parents=True, exist_ok=True)
    path = unique_path(str(HERE / "documents" / f"{label}.json"), doc)
    errors = save_submission(doc, path)
    if errors:
        raise RuntimeError(errors)
    return str(Path(path).relative_to(ROOT))


def deepen(doc, label, trials, seed, numpy_trials=4):
    cached = HERE / "documents" / f"{label}.json"
    if cached.exists():
        measured = json.loads(cached.read_text())
        best = measured if measured["distance"]["d"] < doc["distance"]["d"] else doc
        return best, {
            "document": str(cached.relative_to(ROOT)),
            "recovered_saved_screen": True,
            "completed_fast_trials_per_doubled_side": trials,
            "completed_numpy_pauli_trials": numpy_trials,
            "seed": seed,
        }
    start = time.monotonic()
    result = hd.estimate(doc, trials=numpy_trials, seed=seed, fast_trials=trials, max_seconds=None, fold_trials=0)
    # No wall cap: the documented iteration budgets finish or this call fails.
    p = result["sides"]["P"]
    measured = copy.deepcopy(doc)
    measured["distance"] = {
        "d": p["lightest_found"],
        "P": {
            "value": p["lightest_found"],
            "confidence": "upper_bound",
            "witness": p["witness"],
            "witness_provenance": {
                "found_by": ["@nihoniumqc"],
                "date": "2026-10-23",
                "tool": result["method"],
                "seeds": [seed],
                "found_at_samples": trials,
            },
        },
    }
    measured["name"] = f"[[{doc['n']},{doc['k']},{p['lightest_found']}]] halved CPM pilot"
    path = stage(measured, label)
    record = {
        "result": result,
        "document": path,
        "completed_fast_trials_per_doubled_side": trials,
        "completed_numpy_pauli_trials": numpy_trials,
        "wall_seconds": time.monotonic() - start,
    }
    best = measured if measured["distance"]["d"] < doc["distance"]["d"] else doc
    return best, record


def main():
    HERE.mkdir(parents=True, exist_ok=True)
    cases = [(3, 8, p) for p in [17, 29, 43, 61, 83, 103] for _ in range(2)]
    cases += [(4, 10, p) for p in [29, 43, 61, 83] for _ in range(2)]
    spec = scaffold_campaign(
        HERE.name,
        "Non-CSS stabilizer efficiency pilot, 23 October 2026",
        budget={"candidates_screened": len(cases), "walltime_hours": 1},
        families=["other"],
        constraints={"n": [1, 700], "max_check_weight": 32},
        notes="Symplectic-halved CPM. Provisional efficiency only; no find without the trusted gate.",
    )
    if not (HERE / "campaign.json").exists():
        write_campaign(spec, str(HERE / "campaign.json"))
    led = Ledger(
        load_campaign(str(HERE / "campaign.json")),
        journal=str(HERE / "journal.jsonl"),
        manifest=str(HERE / "manifest.json"),
        params={"upstream_commit": PIN, "seed": SEED},
    )
    dump(
        HERE / "environment.json",
        {
            "upstream_commit": PIN,
            "python": platform.python_version(),
            "numpy": np.__version__,
            "accelerator": hd._fast.__file__,
            "cases": cases,
            "seed": SEED,
            "author": "@nihoniumqc",
        },
    )
    results = json.loads((HERE / "results.json").read_text()) if (HERE / "results.json").exists() else []
    if (HERE / "journal.jsonl").exists():
        led = Ledger.from_journal(load_campaign(str(HERE / "campaign.json")), str(HERE / "journal.jsonl"))
        led.journal = str(HERE / "journal.jsonl")
        led.manifest_path = str(HERE / "manifest.json")
    for i, (j, ell, p) in enumerate(cases):
        if any(r["draw"] == i for r in results):
            continue
        seed = SEED + i
        rec = {
            "draw": i,
            "J": j,
            "L": ell,
            "P": p,
            "eta": -1,
            "sigma": "shift",
            "seed": seed,
            "max_attempts": 200,
            "cycles": False,
        }
        led.start_experiment("other", seed=seed, mode="novel_generation", params=rec)
        try:
            ex, ez, hx, hz, _ = halved.draw_instance(j, ell, p, seed, keep=1, max_attempts=200, verbose=False)[0]
        except RuntimeError as error:
            rec.update(status="constructor_exhausted", reason=str(error))
        else:
            s, n, k = halved.halve(hx, hz, j, ell, p)
            a, b = s[:, :n], s[:, n:]
            rec.update(EX=ex.tolist(), EZ=ez.tolist(), n=n, k=k, w=int((a | b).sum(axis=1).max()))
            lc = qv.is_css_up_to_local_clifford(a, b)
            blocks, sizes = qv._symplectic_block_count(s, n)
            rec.update(locally_css=lc is not None, independent_blocks=blocks, block_sizes=sizes)
            if lc is not None:
                rec.update(status="rejected_locally_css", local_clifford=lc)
            elif blocks != 1:
                rec.update(status="rejected_direct_sum")
            else:
                args = argparse.Namespace(
                    authors=["@nihoniumqc"],
                    name=None,
                    family="other",
                    construction=(
                        f"Symplectic-halved CPM via research/build_halved_pp.py at {PIN}; "
                        f"J={j}, L={ell}, P={p}, eta=-1, shift sigma, seed={seed}."
                    ),
                    date="2026-10-23",
                    model="gpt-6-astra-wm",
                    notes="Research screening only. Literature novelty unknown.",
                    trials=4,
                    fast_trials=0,
                    seed=seed,
                    _coords=None,
                )
                initial = HERE / "documents" / f"draw-{i}-initial.json"
                doc = (
                    json.loads(initial.read_text()) if initial.exists() else cli.build_stabilizer_submission(a, b, args)
                )
                rec["initial_document"] = stage(doc, f"draw-{i}-initial")
                doc, screen = deepen(doc, f"draw-{i}-screen", 4000, seed + 1000)
                rec.update(
                    status="screened_gate_not_run",
                    screen=screen,
                    best_d_upper_bound=doc["distance"]["d"],
                    rate=k / n,
                    efficiency_upper_bound=k * doc["distance"]["d"] ** 2 / n,
                )
                rec["best_document"] = stage(doc, f"draw-{i}-best")
                led.record_screen(trials=4000, d=doc["distance"]["d"], backend="mixed", n=n, k=k)
        led.spend(candidates_screened=1)
        led.record_negative(rec["status"], "Pilot outcome; not an accepted submission.")
        led.record_verdict("not_run")
        led.end_experiment()
        results.append(rec)
        dump(HERE / "results.json", results)
        write_summary(led.summary(), str(HERE / "summary.json"))
        print(
            json.dumps(
                {
                    k: v
                    for k, v in rec.items()
                    if k in ["draw", "status", "n", "k", "w", "best_d_upper_bound", "efficiency_upper_bound"]
                }
            ),
            flush=True,
        )


if __name__ == "__main__":
    main()
