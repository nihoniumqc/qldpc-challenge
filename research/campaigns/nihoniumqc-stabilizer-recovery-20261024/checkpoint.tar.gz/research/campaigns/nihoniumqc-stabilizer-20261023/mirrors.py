"""Fold CPM parents along block-affine X/Z mirrors; attribute every parent.

Technique: upstream fieldnotes/2026-09-28-symplectic-doubling-and-halving.md
and notes/452-115-18.md. This is a derived-code search, not a new family.
"""

import argparse
import copy
import itertools
import json

import numpy as np
from run import HERE, PIN, ROOT, SEED, cli, deepen, dump, hd, qv, stage

PARENTS = [
    "568-146-18",
    "872-222-20",
    "808-206-20",
    "904-230-22",
    "928-238-22",
    "976-250-22",
    "776-198-20",
    "912-234-22",
]


def pairings(xs):
    if not xs:
        yield []
        return
    u = xs[0]
    for v in xs[1:]:
        for tail in pairings([x for x in xs[1:] if x != v]):
            yield [(u, v)] + tail


def mirrors(ex, ez, p):
    for pairs in pairings(list(range(8))):
        sigma = np.zeros(8, dtype=int)
        for u, v in pairs:
            sigma[u], sigma[v] = v, u
        for rho in itertools.permutations(range(3)):
            mat = (ex + ez[list(rho)][:, sigma]) % p
            if not np.all((mat - mat[0]) % p == ((mat - mat[0]) % p)[:, 0:1]):
                continue
            c = (-mat[0]) % p
            if np.array_equal(c, c[sigma]):
                yield sigma, c, rho


def main():
    dest = HERE / "mirrors.json"
    results = json.loads(dest.read_text()) if dest.exists() else []
    for draw, slug in enumerate(PARENTS):
        if any(r["parent"] == slug for r in results):
            continue
        parent = json.loads((ROOT / "codes" / f"{slug}.json").read_text())
        p = parent["n"] // 8
        ex, ez = [], []
        for key, target in [("X", ex), ("Z", ez)]:
            for i in range(3):
                row = parent["checks"][key][i * p]
                target.append([next((-q) % p for q in row if q // p == ell) for ell in range(8)])
        ex, ez = np.array(ex), np.array(ez)
        hx = cli._matrix_from_supports(parent["checks"]["X"], parent["n"])
        for mi, (sigma, c, rho) in enumerate(mirrors(ex, ez, p)):
            seed = SEED + 5000 + 10 * draw + mi
            partner = np.array([sigma[q // p] * p + (c[q // p] - q % p) % p for q in range(8 * p)])
            assert np.array_equal(partner[partner], np.arange(8 * p))
            first = [q for q in range(8 * p) if q < partner[q]]
            order = first + partner[first].tolist()
            n = len(first)
            s = hx[:, order]
            a, b = s[:, :n], s[:, n:]
            rec = {
                "parent": slug,
                "parent_authors": parent["provenance"]["authors"],
                "upstream_commit": PIN,
                "mirror": mi,
                "seed": seed,
                "P": p,
                "EX": ex.tolist(),
                "EZ": ez.tolist(),
                "sigma": sigma.tolist(),
                "c": c.tolist(),
                "rho": list(rho),
                "n": n,
                "k": n - qv.gf2.rank(s),
                "w": int((a | b).sum(axis=1).max()),
            }
            lc = qv.is_css_up_to_local_clifford(a, b)
            blocks, sizes = qv._symplectic_block_count(s, n)
            rec.update(locally_css=lc is not None, independent_blocks=blocks, block_sizes=sizes)
            if lc is not None or blocks != 1:
                rec["status"] = "structural_rejection"
            else:
                args = argparse.Namespace(
                    authors=["@nihoniumqc"],
                    name=None,
                    family="other",
                    construction=(
                        f"Mirror fold of {slug} by {parent['provenance']['authors']} at {PIN}. "
                        "Symplectic halving as in upstream fieldnote and 452-115-18; "
                        f"tau(l,t)=(sigma(l),c_l-t), with sigma={sigma.tolist()}, "
                        f"c={c.tolist()} modulo {p}. Derived construction; parent credited."
                    ),
                    date="2026-10-23",
                    model="gpt-6-astra-wm",
                    notes="Research screening only. Derived from an existing CSS parent; literature novelty unknown.",
                    trials=4,
                    fast_trials=0,
                    seed=seed,
                    _coords=None,
                )
                doc = cli.build_stabilizer_submission(a, b, args)
                label = f"mirror-{draw}-{mi}"
                rec["initial_document"] = stage(doc, label + "-initial")
                rec["mapped_parent_witnesses"] = []
                for side in ["X", "Z"]:
                    v = np.zeros(8 * p, dtype=np.int8)
                    v[parent["distance"][side]["witness"]] = 1
                    v = v[order]
                    if side == "Z":
                        v = np.concatenate([v[n:], v[:n]])
                    assert hd.valid_pauli_logical(v, a, b)
                    weight = int(hd.pauli_weight_rows(v[None, :], n)[0])
                    mapped = copy.deepcopy(doc)
                    mapped["distance"] = {
                        "d": weight,
                        "P": {
                            "value": weight,
                            "confidence": "upper_bound",
                            "witness": hd.pauli_witness(v, n),
                            "witness_provenance": {
                                "found_by": ["@nihoniumqc"],
                                "date": "2026-10-23",
                                "found_at_samples": 1,
                                "tool": f"Deterministic fold of {slug} {side} witness",
                            },
                        },
                    }
                    mapped["name"] = f"[[{n},{rec['k']},{weight}]] mirror fold of {slug}"
                    path = stage(mapped, label + f"-parent-{side}")
                    rec["mapped_parent_witnesses"].append({"side": side, "document": path, "weight": weight})
                    if weight < doc["distance"]["d"]:
                        doc = mapped
                doc, screen = deepen(doc, label + "-screen", 4000, seed + 1000)
                rec.update(
                    status="screened_gate_not_run",
                    screen=screen,
                    best_d_upper_bound=doc["distance"]["d"],
                    rate=rec["k"] / n,
                    efficiency_upper_bound=rec["k"] * doc["distance"]["d"] ** 2 / n,
                    best_document=stage(doc, label + "-best"),
                )
            results.append(rec)
            dump(dest, results)
            print(
                json.dumps(
                    {
                        key: value
                        for key, value in rec.items()
                        if key
                        in ["parent", "mirror", "status", "n", "k", "w", "best_d_upper_bound", "efficiency_upper_bound"]
                    }
                ),
                flush=True,
            )


if __name__ == "__main__":
    main()
