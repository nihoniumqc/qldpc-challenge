"""Optimize short cycles inside a halving-compatible exponent solution space.

Cycle-form enumeration follows our pinned 22 October CPM campaign; the
constructor is official build_halved_pp. No distance checker is implemented here.
"""

import argparse
import itertools
import json
import time

import numpy as np
from run import HERE, PIN, SEED, cli, deepen, dump, halved, qv, stage


def forms(t, j=3, ell=8):
    rows = [r for r in itertools.product(range(j), repeat=t) if all(r[i] != r[(i + 1) % t] for i in range(t))]
    cols = [c for c in itertools.product(range(ell), repeat=t) if all(c[i] != c[(i + 1) % t] for i in range(t))]
    out = set()
    for r in rows:
        for c in cols:
            f = [0] * (j * ell)
            for i in range(t):
                f[ell * r[i] + c[i]] += 1
                f[ell * r[(i + 1) % t] + c[i]] -= 1
            first = next((v for v in f if v), 0)
            if first:
                out.add(tuple(f if first > 0 else [-v for v in f]))
    return np.array(sorted(out), dtype=np.int64)


def equations(ex, p):
    # Recover a valid matching from each even-multiplicity T_ij value class.
    rows, matchings = [], []
    for i, j in itertools.combinations(range(3), 2):
        t = (ex[i] + np.roll(ex[j], 4)) % p
        pairs = []
        for value in sorted(set(t.tolist())):
            indices = np.flatnonzero(t == value).tolist()
            assert len(indices) % 2 == 0
            pairs += list(zip(indices[::2], indices[1::2]))
        for u, v in pairs:
            row = np.zeros(24, dtype=np.int64)
            row[8 * i + u] += 1
            row[8 * i + v] -= 1
            row[8 * j + (u + 4) % 8] += 1
            row[8 * j + (v + 4) % 8] -= 1
            rows.append(row)
        matchings.append([i, j, pairs])
    return np.array(rows), matchings


def main():
    dest = HERE / "optimized.json"
    results = json.loads(dest.read_text()) if dest.exists() else []
    fs = [forms(t) for t in [2, 3, 4]]
    mat = np.vstack(fs)
    cuts = np.cumsum([len(f) for f in fs])
    for draw, p in enumerate([73, 89, 109, 127] * 3):
        if any(r["draw"] == draw for r in results):
            continue
        start = time.monotonic()
        seed = SEED + 2000 + draw
        rng = np.random.default_rng(seed)
        ex, _, _, _, _ = halved.draw_instance(3, 8, p, seed, keep=1, max_attempts=400, verbose=False)[0]
        eq, matchings = equations(ex, p)
        basis = np.array(halved.nullspace_mod(eq, p)[0])
        delta = (mat @ basis.T) % p
        active = np.flatnonzero(np.any(delta != 0, axis=0))
        x = ex.ravel().copy()
        vals = (mat @ x) % p

        def score(v):
            return tuple(int(np.count_nonzero(a == 0)) for a in np.split(v, cuts[:-1]))

        initial = score(vals)
        best = initial
        for _ in range(12000):
            col = int(rng.choice(active))
            amount = int(rng.integers(1, p))
            trial = (vals + amount * delta[:, col]) % p
            cost = score(trial)
            if cost <= best:
                x, vals, best = (x + amount * basis[col]) % p, trial, cost
        ex = x.reshape(3, 8)
        ez = (-np.roll(ex, 4, axis=1)) % p
        hx, hz = halved.circulant_build(ex, ez, p)
        s, n, k = halved.halve(hx, hz, 3, 8, p)
        a, b = s[:, :n], s[:, n:]
        rec = {
            "draw": draw,
            "seed": seed,
            "P": p,
            "J": 3,
            "L": 8,
            "moves": 12000,
            "matchings": matchings,
            "nullity": len(basis),
            "initial_cycle_cost": initial,
            "optimized_cycle_cost": best,
            "EX": ex.tolist(),
            "EZ": ez.tolist(),
            "n": n,
            "k": k,
            "w": int((a | b).sum(axis=1).max()),
        }
        lc = qv.is_css_up_to_local_clifford(a, b)
        blocks, sizes = qv._symplectic_block_count(s, n)
        rec.update(locally_css=lc is not None, independent_blocks=blocks, block_sizes=sizes)
        if lc is not None or blocks != 1:
            rec["status"] = "structural_rejection"
        else:
            args = argparse.Namespace(
                authors=["@nihoniumqc"],
                name=None,
                family="other",
                construction=(
                    f"Optimized symplectic-halved CPM based on build_halved_pp.py at {PIN}; "
                    f"J=3,L=8,P={p},eta=-1,shift sigma,seed={seed}. "
                    "Exponents and matching constraints preserved in the research checkpoint."
                ),
                date="2026-10-23",
                model="gpt-6-astra-wm",
                notes="Research screening only; literature novelty unknown.",
                trials=4,
                fast_trials=0,
                seed=seed,
                _coords=None,
            )
            doc = cli.build_stabilizer_submission(a, b, args)
            rec["initial_document"] = stage(doc, f"opt-{draw}-initial")
            doc, screen = deepen(doc, f"opt-{draw}-screen", 4000, seed + 1000)
            rec.update(
                status="screened_gate_not_run",
                screen=screen,
                best_d_upper_bound=doc["distance"]["d"],
                rate=k / n,
                efficiency_upper_bound=k * doc["distance"]["d"] ** 2 / n,
                best_document=stage(doc, f"opt-{draw}-best"),
            )
        rec["wall_seconds"] = time.monotonic() - start
        results.append(rec)
        dump(dest, results)
        print(
            json.dumps(
                {
                    key: value
                    for key, value in rec.items()
                    if key
                    in [
                        "draw",
                        "status",
                        "n",
                        "k",
                        "w",
                        "optimized_cycle_cost",
                        "best_d_upper_bound",
                        "efficiency_upper_bound",
                    ]
                }
            ),
            flush=True,
        )


if __name__ == "__main__":
    main()
