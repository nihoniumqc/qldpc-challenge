"""Independent Pauli and frame searches for the mirror-fold shortlist."""

import argparse
import copy
import json
import time

from run import HERE, ROOT, SEED, deepen, dump, hd, stage


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--fast-trials", type=int, default=100000)
    parser.add_argument("--numpy-trials", type=int, default=100)
    parser.add_argument("--indices", type=int, nargs="*", default=list(range(8)))
    parser.add_argument("--seed-offset", type=int, default=8000)
    parser.add_argument("--frames", action="store_true")
    args = parser.parse_args()
    dest = HERE / f"confirmation-{args.fast_trials}-{args.seed_offset}.json"
    results = json.loads(dest.read_text()) if dest.exists() else []
    mirrors = json.loads((HERE / "mirrors.json").read_text())
    for index in args.indices:
        if any(r["index"] == index for r in results):
            continue
        source = mirrors[index]
        label = f"confirm-{index}-{args.fast_trials}-{args.seed_offset}"
        seed = SEED + args.seed_offset + index
        doc = json.loads((ROOT / source["best_document"]).read_text())
        # Carry all earlier witnesses, independent of the rung's reading.
        for old in sorted(HERE.glob("confirmation-*.json")):
            for previous in json.loads(old.read_text()):
                if previous["index"] == index:
                    earlier = json.loads((ROOT / previous["best_document"]).read_text())
                    if earlier["distance"]["d"] < doc["distance"]["d"]:
                        doc = earlier
        best, screen = deepen(doc, label, args.fast_trials, seed, args.numpy_trials)
        rec = {
            "index": index,
            "parent": source["parent"],
            "seed": seed,
            "n": doc["n"],
            "k": doc["k"],
            "w": source["w"],
            "screen": screen,
        }
        if args.frames:
            a, b = hd.stabilizer_matrices(doc)
            start = time.monotonic()
            fold = hd.orbit_fold_min_pauli_logical(a, b, 300, seed + 100, max_seconds=30.0, frames=12)
            rec["fold"] = {
                "seed": seed + 100,
                "requested_trials_per_partition": 300,
                "time_limit_seconds": 30,
                "wall_seconds": time.monotonic() - start,
                "partitions": fold["partitions"],
                "frames": fold["frames"],
                "completed_frame_fast_trials_per_doubled_side": fold["frames"] * min(1200, hd.FRAME_TRIALS_MAX),
                "partition_trials_completed": "not exposed by official time-capped API",
            }
            if fold.get("P") is not None:
                weight, v = fold["P"]
                measured = copy.deepcopy(doc)
                measured["name"] = f"[[{doc['n']},{doc['k']},{weight}]] mirror fold"
                measured["distance"] = {
                    "d": weight,
                    "P": {"value": weight, "confidence": "upper_bound", "witness": hd.pauli_witness(v, doc["n"])},
                }
                rec["fold"]["document"] = stage(measured, label + "-fold")
                rec["fold"]["best_d_upper_bound"] = weight
                if weight < best["distance"]["d"]:
                    best = measured
        rec.update(
            best_document=stage(best, label + "-best"),
            best_d_upper_bound=best["distance"]["d"],
            rate=doc["k"] / doc["n"],
            efficiency_upper_bound=doc["k"] * best["distance"]["d"] ** 2 / doc["n"],
        )
        results.append(rec)
        dump(dest, results)
        print(
            json.dumps(
                {
                    key: value
                    for key, value in rec.items()
                    if key in ["index", "parent", "n", "k", "best_d_upper_bound", "efficiency_upper_bound"]
                }
            ),
            flush=True,
        )


if __name__ == "__main__":
    main()
