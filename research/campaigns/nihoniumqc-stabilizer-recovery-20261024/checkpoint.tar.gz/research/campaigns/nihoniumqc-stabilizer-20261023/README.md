# Stabilizer search checkpoint

Author: @nihoniumqc. Computed on 23 October 2026 and recovered on 24 October.
Search base: upstream commit 20300a96a1d8ee4d766cf250352aaae14963a610.

This checkpoint contains 20 raw halved-CPM attempts (19 constructed, one exhausted),
12 short-cycle optimized constructions, and eight mirror folds of existing CSS
parents. All 39 constructed codes received 4,000 accelerated trials per doubled
side plus eight NumPy Pauli trials. Each returned screening witness was packaged
with the official tools. The initial failed save was replayed; recovery.json
records the error and extra four NumPy trials. No code here is a submission.

The eight mirror folds also received 100,000 accelerated trials per doubled side,
100 NumPy Pauli trials, and an official time-capped orbit/random-frame pass.
The 284-qubit fold received a further million accelerated trials per doubled side
and 1,000 NumPy Pauli trials, retaining a witnessed distance upper bound of 17.
Its rate is 73/284 and its provisional score is 74.285211. This establishes a
stabilizer search baseline; the earlier CSS scores are not a matched-track comparison.
No exact distance or achieved efficiency is claimed.

The raw and optimized exponent arrays, seeds and constraints are in results.json
and optimized.json. mirrors.json gives parent attribution and the affine mirror
permutation. The documents directory preserves matrices and returned witnesses;
confirmation files record completed budgets, independent seeds and frame counts.
The 904-qubit parent's fold is a calibration related to the existing 452-115-18
entry and must not be refiled. General permutation equivalence and literature
novelty remain unresolved for other folds.

The constructor is upstream research/build_halved_pp.py. Mirror folding follows
upstream fieldnotes/2026-09-28-symplectic-doubling-and-halving.md and
notes/452-115-18.md; this is an established construction technique. The four
Python scripts here reproduce construction, screening, optimization and deeper
confirmation using the unchanged official tools. Run them from the repository
root with the repository research dependencies and compiled gf2_fast extension.
Existing result files are resumed rather than silently overwritten.

The structural-board-comparison file explicitly used refute=False for early
screening and is not a successful distance gate. Submission requires the current
trusted gate, full confirmation ladder, frontier/dedup checks and publishing checks.
